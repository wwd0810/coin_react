import React, { Suspense } from "react";
import { Switch, withRouter, RouteComponentProps, RouteProps, Redirect } from "react-router";
import { BrowserRouter as Router, Route } from "react-router-dom";
import { withCookies, ReactCookieProps } from "react-cookie";
import { Helmet } from "react-helmet";

import Loading from "components/common/loading";

interface Props extends RouteComponentProps, ReactCookieProps {}

interface PrivateRouteProps extends RouteProps {
  component: React.ComponentType<{}>;
  role: string[] | string;
}

const HomePage = React.lazy(() => import("pages/home/HomePage"));
const DealPage = React.lazy(() => import("pages/deal/DealPage"));
const ListPage = React.lazy(() => import("pages/list/ListPage"));
const MyPage = React.lazy(() => import("pages/mypage/MyPagePage"));
const NoticePage = React.lazy(() => import("pages/center/notice/NoticePage"));

class App extends React.Component<Props> {
  PrivateRoute = ({ component: Component, ...other }: PrivateRouteProps) => {
    return (
      <Route
        {...other}
        render={(props: any) => {
          // if (this.state.isLoading) return null;
          // if (!this.UserStore.IsLoggedIn) {
          alert("로그인이 필요합니다.");
          return <Redirect to="/" />;
          // }

          // return <Component {...props} />;
        }}
      />
    );
  };
  render() {
    return (
      <Router>
        <Helmet>
          <title>CASH LINK</title>
        </Helmet>
        <Suspense fallback={<Loading />}>
          <Switch>
            <Route exact path="/" component={HomePage} />
            <Route exact path="/home" component={HomePage} />
            <Route exact path="/deal" component={DealPage} />
            <Route exact path="/list" component={ListPage} />
            <Route exact path="/mypage" component={MyPage} />
            <Route exact path="/center/notice" component={NoticePage} />
          </Switch>
        </Suspense>
      </Router>
    );
  }
}

export default withCookies(withRouter(App));
