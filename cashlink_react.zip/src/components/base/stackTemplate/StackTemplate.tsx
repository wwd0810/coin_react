import React from "react";
import styled from "styled-components";
import { withRouter, RouteComponentProps } from "react-router";
import { withCookies, ReactCookieProps } from "react-cookie";
import StackHeader from "components/common/header/stack";

interface Props extends RouteComponentProps, ReactCookieProps {
  title: String;
  children: React.ReactNode;
}

class StackTemplate extends React.Component<Props> {
  onPrevClick = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    this.props.history.goBack();
  };

  render() {
    return (
      <Wrap>
        <StackHeader title={this.props.title} onPrev={this.onPrevClick} />
        <div className="content">{this.props.children}</div>
      </Wrap>
    );
  }
}

const Wrap = styled.div`

width: 100%;

& > .content {
  width: 100%;
  max-width: 720px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;

  position: absolute;
  top: 52px;
  left: 16px;
  right: 16px;
    
}
  
${({ theme }) => theme.media.mobile`

`}
${({ theme }) => theme.media.tablet`

`}
${({ theme }) => theme.media.desktop`

`}
`;

export default withCookies(withRouter(StackTemplate));
