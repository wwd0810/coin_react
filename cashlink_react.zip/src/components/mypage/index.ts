export { default } from "./MyPage";
