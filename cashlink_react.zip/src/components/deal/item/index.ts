export { default } from "./Dealtem";
