class RootStore {
  constructor() {}
}

export default RootStore;
