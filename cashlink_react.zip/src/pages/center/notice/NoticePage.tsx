import React from "react";
import StackTemplate from "components/base/stackTemplate";

function NoticePage() {
  return <StackTemplate title="공지사항">1</StackTemplate>;
}

export default NoticePage;
