import React from "react";
import { withRouter, RouteComponentProps } from "react-router";
import { withCookies, ReactCookieProps } from "react-cookie";

import MyPage from "components/mypage";

interface Props extends RouteComponentProps, ReactCookieProps {}

class MyPageContainer extends React.Component<Props> {
  render() {
    return <MyPage isLoggined={true} />;
  }
}

export default withCookies(withRouter(MyPageContainer));
